<footer id="footer" class="sm-padding bg-dark">

<div class="container">

<div class="row">
<div class="col-md-12">

<div class="footer-logo">
<a href="index.html"><img src="img/logo-alt.png" alt="logo"></a>
</div>


<ul class="footer-follow">
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="fa fa-instagram"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
<li><a href="#"><i class="fa fa-youtube"></i></a></li>
</ul>


</div>
</div>

</div>

</footer>